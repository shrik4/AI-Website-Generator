# AI Website Generator

A full-stack TypeScript application that generates complete websites using multiple AI providers.

## Features
- Multiple AI providers: OpenAI, Google Gemini, Anthropic Claude, OpenRouter
- User-provided API keys (no server-side secrets)
- Real-time generation progress tracking
- Complete website packages (frontend + backend)
- ZIP download of generated websites

## Setup

1. Install dependencies:
```bash
npm install
```

2. Start development server:
```bash
npm run dev
```

3. Open http://localhost:5000

## Usage

1. Enter a description of the website you want to create
2. Select an AI provider and model
3. Enter your API key for the chosen provider
4. Click "Generate Website"
5. Wait for generation to complete
6. Download the ZIP file with your complete website

## API Keys

You'll need an API key from one of these providers:
- OpenAI: https://platform.openai.com/api-keys
- Google Gemini: https://ai.google.dev/
- Anthropic Claude: https://console.anthropic.com/
- OpenRouter: https://openrouter.ai/

## Architecture

- Frontend: React 18 + TypeScript + Vite
- Backend: Express.js + TypeScript
- UI: Shadcn/ui + Tailwind CSS
- State Management: TanStack Query
- AI Integration: Multiple provider SDKs
- File Generation: JSZip for download packages
